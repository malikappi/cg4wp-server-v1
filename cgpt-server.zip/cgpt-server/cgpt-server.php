<?php
/**
 * Plugin Name: ChatGPT Server
 * Description: A plugin that is used with WooCommerce and creates API Key and verifies that.
 * Version: 1.0.0
 * Author: cod3pk
 * Author URI: https://linkedin.com/in/asfii3191
 * Text Domain: cgpt-server
 */

defined( 'ABSPATH' ) || exit;

define( 'PLUGIN_DIR', __DIR__ );
define( 'PLUGIN_PATH', plugin_dir_url( __FILE__ ) );

// Check if WooCommerce is active
if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	// Display a message to the user that WooCommerce is required
	add_action( 'admin_notices', 'chatgpt_plugin_dependency_notice' );
} else {
	require_once PLUGIN_DIR . '/core/class-configuration.php';
	

	
	
}

/**
 * Database Table Setup
 *
 * @return void
 */
function chatgpt_plugin_db_setup(): void {
	require_once PLUGIN_DIR . '/core/class-db-setup.php';
	
	
}

register_activation_hook( __FILE__, 'chatgpt_plugin_db_setup' );



// Display a notice to the user that WooCommerce is required
function chatgpt_plugin_dependency_notice(): void {
	?>
	<div class="notice notice-error is-dismissible">
		<p><?php _e( 'ChatGPT Server requires WooCommerce to be installed and activated.', 'chatgpt' ); ?></p>
	</div>
	<?php
}


function custom_admin_page() {
    add_menu_page(
        'CG4wp DashBoard',
        'CG4wp DashBoard',
        'manage_options', // Required capability to access
        'cg4wp-dashboard', // Unique menu slug
        'cg4wp_dashboard_callback', // Callback function to display content
        'dashicons-admin-generic', // Icon URL or dashicon class
        10 // Position in the menu (1 is at the top)
    );
}
add_action('admin_menu', 'custom_admin_page');

function cg4wp_dashboard_callback() {
	  global $wpdb;
        $chatgpt_api_keys = $wpdb->prefix . 'chatgpt_api_keys';
		$chatgpt_api_activation_records = $wpdb->prefix . 'chatgpt_api_activation_records';
      echo '<div class="wrap">';
    echo '<h1>Customer Orders Dashboard</h1>';
    
      $users = get_users(array(
        'role__in' => array('customer', 'subscriber'),
       
    ));
	
	
    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr><th>User ID</th><th>Name</th><th>Phone</th><th>Email</th><th>Orders</th></tr></thead>';
    echo '<tbody>';

    foreach ($users as $user) {
		  // Query user orders
        $customer_orders = wc_get_orders(array(
            'customer_id' => $user->ID,
            // Include completed and processing orders
        ));
		$billing_first_name = $user->billing_first_name;
        $billing_last_name = $user->billing_last_name;
		 $billing_phone = $user->billing_phone;
	
		$name = $billing_first_name . ' ' . $billing_last_name;
        echo '<tr>';
		 echo '<td>' . $user->ID. '</td>';
        echo '<td>' . $name . '</td>';
        echo '<td>' . $billing_phone . '</td>';
        echo '<td>' . $user->user_email . '</td>';

      

        echo '<td>';
	
	echo '<button class="btn btn-primary" data-toggle="modal" data-target="#modal-' . $user->ID . '" data-userid="' . $user->ID . '">View Detail</button>';

		
		echo '<div class="modal fade" id="modal-' . $user->ID . '" tabindex="-1" role="dialog" aria-labelledby="modal-' . $user->ID . '-label" aria-hidden="true">';
        echo '<div class="modal-dialog modal-lg">';
        echo '<div class="modal-content">';
        echo '<div class="modal-header">';
        echo '<h5 class="modal-title" id="modal-' . $user->ID . '-label">Orders for ' . $user->user_login . '</h5>';
        echo '<button type="button" class="close" data-dismiss="modal" aria-label="Close">';
        echo '<span aria-hidden="true">&times;</span>';
        echo '</button>';
        echo '</div>';
        echo '<div class="modal-body">';
		
        if ($customer_orders) {
            echo '<ul>';
            foreach ($customer_orders as $order) {
               $order_id = $order->get_id();
                $order = wc_get_order($order_id);
                $order_date = $order->get_date_created()->format('M d, Y');
     
        $api_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM $chatgpt_api_keys WHERE order_id = %s", $order_id));
			
   if ($api_data) {
	      $p_id = $api_data->p_id;
		     $api_key    = get_post_meta( $p_id, 'chatgpt_client_chatgpt_api_key', TRUE );
			 $api_key = $api_data->api_key;
			  $allowed_installations    = get_post_meta( $p_id, 'chatgpt_client_allowed_installations', TRUE );
            echo '<table style="margin-bottom:0px">';
			echo '<tr style="background: #2C3EAB; color: #fff;font-weight: 600;font-size: 18px;">'; 
			echo '<td>Product Name</td>';
			echo '<td>' . $api_data->product_name . '</td>';
            echo '</tr>';
			echo '<tr >'; 
			echo '<td>License Key</td>';
			echo '<td>' . $api_key . '</td>';
            echo '</tr>';
		echo '</table>';
			 echo '<table style="margin-bottom:0px;margin-top:0px">';
			
            echo '<tr>
			<th style="font-weight: bold;">Order Id</th>
			<th style="font-weight: bold;">Date</th>
			
			<th style="font-weight: bold;">Active Installations</th>
			<th style="font-weight: bold;">Allowed Installations</th>
			<th style="font-weight: bold;">Allowed Usuage</th>
			<th style="font-weight: bold;"> Usuage</th>
			<th style="font-weight: bold;">Status</th>
			</tr>';
	   if( $api_data->allowed_usuage == -1){ $allowed_usuage = 'Unlimited';}else{$allowed_usuage = $api_data->allowed_usuage;}
	      
             echo '<tr>';
			 echo '<td>' . $order_id . '</td>';
             echo '<td>' . $order_date . '</td>';
			 echo '<td>' . $api_data->active_installations . '</td>';
             echo '<td>' . $allowed_installations . '</td>';
			  echo '<td>' . $allowed_usuage . '</td>';
			   echo '<td>' . $api_data->remaining_usuage . '</td>';
			   echo '<td>' . $api_data->status . '</td>';
             echo '</tr>';
            echo '</table>';
        }
	$installations = $wpdb->get_results($wpdb->prepare("SELECT * FROM $chatgpt_api_activation_records WHERE api_key = %s", $api_key));
$count = 1;
		 echo '<table style="margin-bottom:0px;margin-top:0px">';
			echo '<tr style="background: #2C3EAB; color: #fff;font-weight: 600;font-size: 12px;">'; 
		    echo '<td>#</td>';
			echo '<td>Website</td>';
			echo '<td>Date</td>';
			echo '</tr>';
if ($installations) {
	
	
    foreach ($installations as $installation) {
     
      echo '<tr style="color: #000;font-weight: 600;font-size: 12px;">'; 
		    echo "<td>$count</td>";
			echo "<td> $installation->site_url</td>";
			echo "<td> $installation->date</td>";
			echo '</tr>';
        $count++;
    }
	
	
} else {
   
	
	  echo '<tr style="color: #000;font-weight: 600;font-size: 12px;">'; 
		    echo "<td>$count</td>";
			echo "<td> No installations found for this API key.</td>";
			echo '</tr>';
}
		   
 echo '</table><br>';		
	

				
				
		
       
            }
            echo '</ul>';
        } else {
            echo 'No orders';
        }
		
		
		 echo '</div>';
        echo '<div class="modal-footer">';
        echo '<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
		
		
        echo '</td>';

        echo '</tr>';
    }

    echo '</tbody></table>';
    echo '</div>';
	
echo "<style>
.popup{display:none;}
.modal{display:none}
.widefat td, .widefat th {
        color: inherit;
}
.modal-lg, .modal-xl {
    max-width: 1000px !important;
}
table {
    border-collapse: collapse;
    width: 100%;
}
.fs-notice.updated.success.fs-has-title.fs-slug-unlimited-elements-for-elementor.fs-type-plugin {
    display: none !important;
}
.fs-type-plugin , .fs-notice , .notice.notice-info {
    display: none !important;
}
	</style>";
	echo '<link rel="stylesheet" id="bootstrap-css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" type="text/css" media="all">

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>';
	echo "<script>
    jQuery(document).ready(function($) {
	
        // Listen for button click and show corresponding modal content
        $('body').on('click', '.btn', function() {
            var userID = $(this).data('userid');
            $('#modal-' + userID).show('show');
        });
    });
</script>";
}
