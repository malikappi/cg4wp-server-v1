<?php
class CGPT_Server_Api_Keys {
    private string $salt = '5C38llP13YaVIARwXsih+QlY0mYXifnprvQIym2N4tYvwXBcZu35aZKHom6I48zWpduk31aK90PQs6KZPPrvhg==';
    private $table_name = 'chatgpt_api_keys';


public function __construct() {
    add_action('woocommerce_new_order', [$this, 'generate_and_update_api_key'], 10, 1);
    add_action('woocommerce_order_details_after_order_table', [$this, 'cgpt_display_api_key'], 10, 1);
}
    /**
     * Generate API Key and save it with order
     *
     * @param int $order_id
     *
     * @throws \Exception
     */
    public function generate_and_update_api_key(int $order_id): void {
		global $wpdb;
        error_log('Generating and updating API key. Order ID: ' . $order_id);
        $table_name = $wpdb->prefix . $this->table_name;
       
        $api_key = $this->generate_api_key();

        $order = wc_get_order($order_id);
   if (!is_a($order, 'WC_Subscription')) {
		//$order_status = $order->get_status();
		
		 $order_status = $wpdb->get_var("SELECT post_status FROM $wpdb->posts WHERE ID = $order_id");

     foreach (WC()->cart->get_cart() as $cart_item) {
        $product_id = $cart_item['product_id'];
        $product_name = $cart_item['data']->get_name();
        $allowed_install = get_post_meta($product_id, 'chatgpt_client_allowed_installations', true);
		 $allowed_days = get_post_meta($product_id, 'chatgpt_client_allowed_days', true);
        $allowed_usage = get_post_meta($product_id, 'chatgpt_client_allowed_usage', true);
		$chatgpt_api_key = get_post_meta($product_id, 'chatgpt_client_chatgpt_api_key', true);
		
		$start_date = date('Y-m-d');
         $expiry_date = date('Y-m-d', strtotime($current_date . ' + ' . $allowed_days . ' days'));

		 
		 $data = [
			'order_id' => $order_id,
			'p_id' => $product_id,
			'api_key'  => $api_key,
			'product_name'  => $product_name,
			'allowed_install'  => $allowed_install,
			'allowed_days'  => $allowed_days,
			'allowed_usuage'  => $allowed_usage,
			'remaining_usuage'  => 0,
			'start_date'  => $start_date,
			'expiry_date'  => $expiry_date,
			'chatgpt_api_key'  => $chatgpt_api_key,
			'status'  => 'wc-completed',
			
		];

		$format = [
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			
			
		];

		$wpdb->insert( $table_name, $data, $format );
		
		
		
    }


}

		
	  }
	
    /**
     * Generate a random API key using the salt
     *
     * @return string
     */
    private function generate_api_key(): string {
        // Your logic to generate the API key using the salt
        $api_key = hash('sha256', uniqid($this->salt, true));

        return $api_key;
    }

    /**
     * Display API Key and active installations count on My Account Page
     *
     * @param $order
     *
     * @return void
     */
    public function cgpt_display_api_key($order): void {
     global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;
		$query      = "SELECT * FROM $table_name WHERE order_id = " . $order->get_id();

		$data = $wpdb->get_row( $query );

		if ( $data ) {
			$api_key               = $data->api_key;
			$active_installs_count = $data->active_installations;
			?>
			<p class="cgpt-core-api-section">
				<strong>
					<?php echo __( 'License Key: ', 'cgpt-server' ); ?>
				</strong> <?php echo $api_key ?>
			</p>
			<p class="cgpt-core-api-section">
				<strong>
					<?php echo __( 'Active install count: ', 'cgpt-server' ); ?>
				</strong> <?php echo ' ' . $active_installs_count ?>
			</p>
			<?php
		}
	}

}

new CGPT_Server_Api_Keys();
?>