<?php

class Chatgpt_API_Endpoint {

	public function __construct() {
		add_action( 'rest_api_init', [
			$this,
			'chatgpt_register_api_endpoint',
		] );
	}

	/**
	 * Route Setup
	 *
	 * @return void
	 */
	public function chatgpt_register_api_endpoint(): void {
		register_rest_route( 'chatgpt-server', '/license-auth', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'chatgpt_license_auth' ],
			'permission_callback' => '__return_true',
		] );

        register_rest_route( 'chatgpt-server', '/update_requests_counts', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'chatgpt_update_requests_counts' ],
			'permission_callback' => '__return_true',
		] );
		
		
		register_rest_route( 'chatgpt-server', '/check-status', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'chatgpt_check_status' ],
			'permission_callback' => '__return_true',
		] );
		
		register_rest_route( 'chatgpt-server', '/eligibility_check', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'chatgpt_eligibility_check' ],
			'permission_callback' => '__return_true',
		] );
	}


/**
	 * Callback for Remaining Usuage
	 *
	 * @param WP_REST_Request $request
	 *
	 * @return WP_REST_Response
	 */
public function chatgpt_eligibility_check( WP_REST_Request $request ): WP_REST_Response {
    global $wpdb;
    $table_name = $wpdb->prefix . 'chatgpt_api_keys';
    $api_key = sanitize_text_field( $request->get_param( 'api_key' ) );
    $requests = sanitize_text_field( $request->get_param( 'requests' ) );

    // Validate input parameters
    if ( empty( $api_key ) ) {
        return new WP_REST_Response( [
            'message' => 'Invalid request. API key is required.',
        ], 400 );
    }

    $data = $this->chatgpt_get_api_key_data( $api_key );

    if ( ! $data ) {
        return new WP_REST_Response( [
            'message' => 'Invalid API key. Unable to proceed with activation.',
        ], 400 );
    }
    $p_id = $data->p_id;
	
	$api_key = get_post_meta( $p_id, 'chatgpt_client_chatgpt_api_key', TRUE );
    $remaining_usuage = $data->remaining_usuage;
	$allowed_usuage = get_post_meta( $p_id, 'chatgpt_client_allowed_usage', TRUE );
	$status           = $data->status;

    if($status == 'wc-completed' || $status == 'processing' || $status == 'completed'){
		
	$remaining_usuage =	$remaining_usuage + $requests;
	
	if( $allowed_usuage <= $remaining_usuage ){
		 return new WP_REST_Response( [
        'error_type' => 'noeligible',
		'status'     => $status,
		'chatgpt_api_key'    => $api_key,
        'message'    => 'You Reach the limit of queries in your Plan, to Upgrade your plan visit our website',
    ], 200 );
	
	}
	
	if($allowed_usuage == '-1'){
		
	return new WP_REST_Response( [
        'error_type' => 'eligible',
		'status'     => $status,
		'chatgpt_api_key'     => $api_key,
        'message'    => 'Your limit is unlimited',
    ], 200 );
	
	}
	
	if($allowed_usuage > $remaining_usuage ){
		 return new WP_REST_Response( [
        'error_type' => 'eligible',
		'status'     => $status,
		'chatgpt_api_key'    => $api_key,
        'message'    => 'limit is available',
    ], 200 );
	}
	
	
	
	
		
	}else{
	$message = "Currently you are not eligible to perform any query, You License Status is $status";
	 return new WP_REST_Response( [
        'error_type'          => 'noeligible',
		'status'              => $status,
		'chatgpt_api_key'     => $api_key,
        'message'             => $message,
    ], 200 );	
		
	}
   
}


/**
	 * Callback for Remaining Usuage
	 *
	 * @param WP_REST_Request $request
	 *
	 * @return WP_REST_Response
	 */
  public function chatgpt_update_requests_counts( WP_REST_Request $request ): WP_REST_Response {
    global $wpdb;
    $table_name = $wpdb->prefix . 'chatgpt_api_keys';
    $api_key = sanitize_text_field( $request->get_param( 'api_key' ) );
    $requests = sanitize_text_field( $request->get_param( 'requests' ) );

    // Validate input parameters
    if ( empty( $api_key ) ) {
        return new WP_REST_Response( [
            'message' => 'Invalid request. API key is required.',
        ], 400 );
    }

    $data = $this->chatgpt_get_api_key_data( $api_key );

    if ( ! $data ) {
        return new WP_REST_Response( [
            'message' => 'Invalid API key. Unable to proceed with activation.',
        ], 400 );
    }

    $remaining_usuage = $data->remaining_usuage;
	$allowed_usuage = $data->allowed_usuage;

   
        // Deduct requests
        $remaining_usuage += $requests;

        // Update the database
        $wpdb->update(
            $table_name,
            array( 'remaining_usuage' => $remaining_usuage ),
            array( 'ID' => $data->ID ),
            array( '%d' ),
            array( '%d' )
        );
        $message = "Your totle usuage is $remaining_usuage. Record is updated";
    

    return new WP_REST_Response( [
        'remaining_usuage' => $remaining_usuage,
        'message'          => $message,
    ], 200 );
}



	/**
	 * Check if the site is already activated
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return WP_REST_Response JSON response indicating whether the URL exists
	 *     or not.
	 */
	public function chatgpt_check_status( WP_REST_Request $request ): WP_REST_Response {
		$api_key  = sanitize_text_field( $request->get_param( 'api_key' ) );
		$site_url = sanitize_url( $request->get_param( 'site_url' ) );
		$site_url = preg_replace( '#^https?://#', '', $site_url );
        
		if ( empty( $site_url ) ) {
			return new WP_REST_Response( [
				'message' => 'The Site URL parameter is empty',
			], 400 );
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'chatgpt_api_activation_records';

		$exists = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $table_name WHERE site_url = %s",
				$site_url,
			)
		);
        // Retrieve data based on the provided API key
		$data = $this->chatgpt_get_api_key_data( $api_key );
		if ( ! $data ) {
			return new WP_REST_Response( [
				'action'  => 'required',
				'message' => 'Invalid API key. Unable to proceed with activation.',
			], 400 );
		}

		$order_id              = $data->order_id;
		$product_name          = $data->product_name;
		$product_type          = $data->product_type;
		$allowed_install       = $data->allowed_install;
		$active_installs_count = $data->active_installations;
		$allowed_days          = $data->allowed_days;
		$allowed_usage         = $data->allowed_usage;
		$remaining_usuage      = $data->remaining_usuage;
		$start_date            = $data->start_date;
        $expiry_date           = $data->expiry_date;
		$chatgpt_api_key       = $data->chatgpt_api_key;
		$status                = $data->status;
		$subscription_activation_limit = $this->chatgpt_get_subscription_activation_limit( $order_id );
		
		
		if ( ! $exists ) {
			return new WP_REST_Response( [
				'action'  => 'required',
				'message' => 'Please enter your license key in order to use the plugin.',
			], 200 );
		} else {
			return new WP_REST_Response( [
				'action'  => 'approved',
				'allowed_install'  => $allowed_install,
			    'product_name'     => $product_name,
				'product_type'     => $product_type,
			    'allowed_usage'    => $allowed_usage,
			    'allowed_days'     => $allowed_days,
			    'start_date'       => $start_date,
                'remaining_usuage' => $remaining_usuage,				
		        'expiry_date'      => $expiry_date,
				'chatgpt_api_key'  => $chatgpt_api_key,
				'status'           => $status,
				'message' => 'This website is already activated.',
			], 200 );
		}
	}

	/**
	 * Callback for License Handler Route
	 *
	 * @param WP_REST_Request $request
	 *
	 * @return WP_REST_Response
	 */
	public function chatgpt_license_auth( WP_REST_Request $request ): WP_REST_Response {
		$api_key  = sanitize_text_field( $request->get_param( 'api_key' ) );
		$site_url = sanitize_url( $request->get_param( 'site_url' ) );
		
		

		// Validate input parameters
		if ( empty( $api_key ) || empty( $site_url ) ) {
			return new WP_REST_Response( [
			 'action'  => 'required',
				'message' => 'Invalid request. API key and Site URL are required.',
			], 400 );
		}

		// Normalize the site URL to remove http:// or https://
		$site_url = preg_replace( '#^https?://#', '', $site_url );
        $data = $this->chatgpt_get_api_key_data( $api_key );
		
		
		$order_id              = $data->order_id;
		$p_id                  = $data->p_id;
		$api_key               = $data->api_key;
		$product_chatgpt_api_key  = get_post_meta( $p_id, 'chatgpt_client_chatgpt_api_key', TRUE );
		$product_name          = $data->product_name;
		$product_type          = $data->product_type;
		$allowed_install       = get_post_meta( $p_id, 'chatgpt_client_allowed_installations', TRUE );
		$active_installs_count = $data->active_installations;
		$allowed_days          = $data->allowed_days;
		$allowed_usuage        = $data->allowed_usuage;
		$remaining_usuage      = $data->remaining_usuage;
		$start_date            = $data->start_date;
        $expiry_date           = $data->expiry_date;
		$chatgpt_api_key       = $product_chatgpt_api_key;
		$status                = $data->status;
		$subscription_activation_limit = $this->chatgpt_get_subscription_activation_limit( $order_id );
		 
		 
		
		
		if ( !$data ) {	
		return new WP_REST_Response( [
				'action'  => 'required',
				'message' => 'License Key is not exist',
			], 400 );

		}
		
		
		
		if ( $data->status == 'on-hold' || $data->status == 'cancelled' || $data->status == 'pending') {
			return new WP_REST_Response( [
				'action'  => 'required',
				'message' => 'Your License status is put on Cancel/On hold.',
			], 400 );
		}
		// Check if the website is already activated
		if ( !$this->chatgpt_check_existing_installation( $site_url, $api_key ) ) {
		
		// Check if the maximum number of installations has been reached
		if ( $active_installs_count >= $subscription_activation_limit ) {
			return new WP_REST_Response( [
				'action'  => 'required',
				'message' => 'You have reached the maximum number of installations. Please upgrade your subscription.',
			], 400 );
		}
		
		}

		// Check if the website is already activated
		if ( $this->chatgpt_check_existing_installation( $site_url, $api_key ) ) {
			
			
			return new WP_REST_Response( [
			'action'  => 'approved',
			'allowed_install' => $allowed_install,
			'product_name'    => $product_name,
			'product_type'    => $product_type,
			'allowed_usage'   => $allowed_usage,
			'allowed_days'    => $allowed_days,
			'remaining_usuage'=> $remaining_usuage,
			'start_date'      => $start_date,		    
		    'expiry_date'     => $expiry_date,
			'chatgpt_api_key' => $chatgpt_api_key,
				'message' => 'The license for this website is already activated.',
			], 200 );
		}
		// Retrieve data based on the provided API key
		
// Check if the maximum number of installations has been reached
		if ( $active_installs_count > $subscription_activation_limit ) {
			return new WP_REST_Response( [
				'action'  => 'required',
				'message' => 'You have reached the maximum number of installations. Please upgrade your subscription.',
			], 400 );
		}
		

		// Prepare data for activation
		$data = [
			'order_id'             => $order_id,
			'site_url'             => $site_url,
  			'api_key'              => $api_key,
			'active_installations' => $active_installs_count,
			'allowed_install'      => $allowed_install,
			'product_name'         => $product_name,
			'product_type'         => $product_type,
			'allowed_usage'        => $allowed_usage,
			'remaining_usuage'     => $remaining_usuage,
			'allowed_days'         => $allowed_days,
			'start_date'           => $start_date,		    
		    'expiry_date'          => $expiry_date,
			'chatgpt_api_key'      => $chatgpt_api_key,
			'status'               => $status,
		];

		// Update the site_url and active_installations_count in the chatgpt_api_keys table
		$this->chatgpt_create_activation_record( $data );

		return new WP_REST_Response( [
			'action'  => 'approved',
			'allowed_install' => $allowed_install,
			'product_name'    => $product_name,
			'product_type'    => $product_type,
			'allowed_usage'   => $allowed_usage,
			'allowed_days'    => $allowed_days,
			'remaining_usuage'=> $remaining_usuage,
			'start_date'      => $start_date,		    
		    'expiry_date'     => $expiry_date,
			'chatgpt_api_key' => $chatgpt_api_key,
			'status'          => $status,
			'message'         => 'This website has been registered successfully.',
		], 200 );

		
	}

	/**
	 * Returns the total installations which have been set to the bought package
	 *
	 * @param $order_id
	 *
	 * @return mixed|void
	 */
	public function chatgpt_get_subscription_activation_limit( $order_id ) {
		$order = wc_get_order( $order_id );
		$items = $order->get_items();

		foreach ( $items as $item_id => $item ) {
			$product = $item->get_product();
			return get_post_meta( $product->id, 'chatgpt_client_allowed_installations', TRUE );
		}
	}

	/**
	 * Activation Record creation
	 *
	 * @param $data
	 *
	 * @return void
	 */
	public function chatgpt_create_activation_record( $data ): void {
		global $wpdb;
        $date = date('Y-m-d');
		$insert_data = [
			'order_id' => $data['order_id'],
			'site_url' => $data['site_url'],
			'api_key'  => $data['api_key'],
			'date'     => $date,
		];

		$wpdb->insert(
			$wpdb->prefix . 'chatgpt_api_activation_records',
			$insert_data,
			[ '%d', '%s', '%s' ]
		);

		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$wpdb->prefix}chatgpt_api_keys
				SET active_installations = %d
				WHERE order_id = %d",
				$data['active_installations'] + 1,
				$data['order_id']
			)
		);
	}

	/**
	 * Check if the site has already been activated
	 *
	 * @param $site_url
	 *
	 */
	public function chatgpt_check_existing_installation( $site_url, $api_key ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'chatgpt_api_activation_records';

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $table_name WHERE site_url = %s AND api_key = %s",
				$site_url,
				$api_key
			)
		);
	}

	/**
	 * Fetch API key data from DB
	 *
	 * @param $api_key
	 *
	 */
	public function chatgpt_get_api_key_data( $api_key ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'chatgpt_api_keys';

		return $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM $table_name WHERE api_key = %s", $api_key )
		);
	}
	public function chatgpt_get_api_key_rows( $api_key ) {
	$result = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE api_key = %s", $api_key));

    return $num_rows = $wpdb->num_rows;

    

	}

}

new Chatgpt_API_Endpoint();
