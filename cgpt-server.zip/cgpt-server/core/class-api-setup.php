<?php
/**
 * API Configuration Class
 */

class CGPT_API_Config {

	public function __construct() {
		$this->include_required_files();
	}

	public function include_required_files(): void {
		require_once 'api/class-api-keys.php';
		require_once 'api/class-api-ops.php';
	}

}

new CGPT_API_Config();