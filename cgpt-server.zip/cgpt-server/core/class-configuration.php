<?php
/**
 * Configuration Class
 */

class CGPT_Server_Config {
private $table_name;
	public function __construct() {
		
		global $wpdb;
        $this->table_name = $wpdb->prefix . 'chatgpt_api_keys';
		
		
		$this->include_required_files();
		add_action( 'wp_enqueue_scripts', [ $this, 'add_required_scripts' ] );
		
        add_action('woocommerce_order_status_changed', array($this, 'custom_order_status_changed'), 10, 3);
   }

	/**
	 * Required scripts addition
	 *
	 * @return void
	 */
	 


   // Function to update the status in your custom table
    public function update_custom_status($order_id, $new_status) {
        global $wpdb;

        $data = array('status' => $new_status);
        $where = array('order_id' => $order_id);

        $wpdb->update($this->table_name, $data, $where);
    }

    // Callback function for the action hook
    public function custom_order_status_changed($order_id, $old_status, $new_status) {
        // Check if the status change is being done by an admin
        if (current_user_can('manage_woocommerce') || current_user_can('edit_shop_orders')) {
            // Call the custom function to update the status in your table
            $this->update_custom_status($order_id, $new_status);
        }
    }





	public function add_required_scripts(): void {
		wp_enqueue_style( 'cgpt-server-css', PLUGIN_PATH . 'assets/css/app.css', '', '1.0' );
		
	}

	/**
	 * Including Core and API Dir
	 *
	 * @return void
	 */
	public function include_required_files(): void {
		require_once 'class-metabox.php';
		require_once 'class-api-setup.php';
	}

}

new CGPT_Server_Config();