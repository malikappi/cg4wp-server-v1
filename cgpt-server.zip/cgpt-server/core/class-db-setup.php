<?php

/**
 * Database Class
 */
class CGPT_DB_Setup {

	public function __construct() {
		$this->cgpt_create_api_records_table();
		$this->cgpt_create_api_installations_table();
	}

	/**
	 * API Order Records Table
	 *
	 * @return void
	 */
	public function cgpt_create_api_records_table(): void {
		global $wpdb;

		$table_name   = $wpdb->prefix . 'chatgpt_api_keys';
		$table_exists = get_option( 'chatgpt_api_keys_table_status', FALSE );

		if ( ! $table_exists ) {
			$sql = "CREATE TABLE $table_name (
					ID INT(11) NOT NULL AUTO_INCREMENT,
					order_id VARCHAR(255),
					api_key VARCHAR(255),
					product_name VARCHAR(255),
					product_type VARCHAR(255),
					allowed_install INT(11),
					active_installations INT(11) DEFAULT 0,
					allowed_install INT(11),
					allowed_days INT(11),
					allowed_usuage INT(11),
					remaining_usuage INT(11),
					start_date varchar(50),
					expiry_date varchar(50),
					chatgpt_api_key VARCHAR(255),
					status INT(11),
					PRIMARY KEY (ID)
					) " . $wpdb->get_charset_collate() . ";";

			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			dbDelta( $sql );

			update_option( 'chatgpt_api_keys_table_status', TRUE );
		}
	}

	/**
	 * API Installations Record Table Setup
	 *
	 * @return void
	 */
	public function cgpt_create_api_installations_table(): void {
		global $wpdb;

		$table_name   = $wpdb->prefix . 'chatgpt_api_activation_records';
		$table_exists = get_option( 'chatgpt_api_activation_records_table_status', FALSE );

		if ( ! $table_exists ) {
			$sql = "CREATE TABLE $table_name (
					ID INT(11) NOT NULL AUTO_INCREMENT,
					order_id VARCHAR(255),
					api_key VARCHAR(255),
					site_url VARCHAR(255),
					PRIMARY KEY (ID)
					) " . $wpdb->get_charset_collate() . ";";

			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			dbDelta( $sql );

			update_option( 'chatgpt_api_activation_records_table_status', TRUE );
		}
	}

}

new CGPT_DB_Setup();
