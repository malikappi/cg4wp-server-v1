<?php

class CGPT_Server_Metabox {

	private $table_name = 'chatgpt_api_keys';

	public function __construct() {
		add_action( 'add_meta_boxes', [
			$this,
			'register_order_api_metabox',
		] );

		add_action( 'woocommerce_product_options_general_product_data', [
			$this,
			'add_custom_field_to_product_general_tab',
		] );

		add_action( 'woocommerce_process_product_meta', [
			$this,
			'save_custom_field_value',
		] );
	}

	public function register_order_api_metabox(): void {
		add_meta_box(
			'cgpt_product_custom_metabox',
			'License Key Details',
			[ $this, 'render_order_api_metabox' ],
			'shop_order',
			'normal',
			'high'
		);
	}

	public function render_order_api_metabox( $post ): void {
		global $wpdb;

		$table_name = $wpdb->prefix . $this->table_name;

		$data = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM $table_name WHERE order_id = %s", $post->ID )
		);

		$api_key               = $data->api_key;
		$active_installs_count = $data->active_installations;

		echo '<p><strong>License Key</strong>: ' . esc_html( $api_key ) . '</p>';
		echo '<p><strong>Active install count</strong>: ' . ' ' . $active_installs_count . '</p>';
	}

	public function add_custom_field_to_product_general_tab() {
		global $product_object;
		$product_type = get_post_meta( $product_object->get_id(), 'chatgpt_client_product_type', TRUE );
        echo '<div class="product_custom_field">
		<p class="form-field chatgpt_client_product_type ">
		<label for="chatgpt_client_product_type">Select Product Type</label>
		<select name="chatgpt_client_product_type" id="chatgpt_client_product_type">'?>
		<option value="free" <?php if($product_type == 'free'){ echo 'selected';}?>>FREE</option>
		<option value="starter" <?php if($product_type == 'starter'){ echo 'selected';}?>>STARTER</option>
		<option value="pro">PRO</option>
		<option value="unlimited" <?php if($product_type == 'unlimited'){ echo 'selected';}?>>UNLIMITED</option>
		<option value="custom" <?php if($product_type == 'custom'){ echo 'selected';}?>>CUSTOM</option></select>;
		
		<?php echo '</p></div>'; 
		
		
		echo '<div class="product_custom_field">';
		woocommerce_wp_text_input( [
			'id'          => 'chatgpt_client_allowed_installations',
			'label'       => __( 'Allowed Installations', 'woocommerce' ),
			'description' => __( 'Enter the number of allowed installations for this product.', 'woocommerce' ),
			'value'       => get_post_meta( $product_object->get_id(), 'chatgpt_client_allowed_installations', TRUE ),
		] );
		echo '</div>';
		
		echo '<div class="product_custom_field">';
		woocommerce_wp_text_input( [
			'id'          => 'chatgpt_client_allowed_usage',
			'label'       => __( 'Allowed Usage', 'woocommerce' ),
			'description' => __( 'Enter the number of allowed attempt for this product.<br>Note:For unlimited -1', 'woocommerce' ),
			'value'       => get_post_meta( $product_object->get_id(), 'chatgpt_client_allowed_usage', TRUE ),
		] );
		echo '</div>';
		
		
				echo '<div class="product_custom_field">';
		woocommerce_wp_text_input( [
			'id'          => 'chatgpt_client_allowed_days',
			'label'       => __( 'Allowed Days', 'woocommerce' ),
			'description' => __( 'Enter the number of allowed day for this product.<br>Note:For unlimited 1000', 'woocommerce' ),
			'value'       => get_post_meta( $product_object->get_id(), 'chatgpt_client_allowed_days', TRUE ),
		] );
		echo '</div>';
		
				echo '<div class="product_custom_field">';
		woocommerce_wp_text_input( [
			'id'          => 'chatgpt_client_chatgpt_api_key',
			'label'       => __( 'ChatGpt API key', 'woocommerce' ),
			'description' => __( 'Enter the ChatGpt API key', 'woocommerce' ),
			'value'       => get_post_meta( $product_object->get_id(), 'chatgpt_client_chatgpt_api_key', TRUE ),
		] );
		echo '</div>';
		
		
		
		
		
	}

	public function save_custom_field_value( $post_id ) {
		$allowed_installations = isset( $_POST['chatgpt_client_allowed_installations'] ) ? sanitize_text_field( $_POST['chatgpt_client_allowed_installations'] ) : '';
		
		$chatgpt_client_allowed_usage = isset( $_POST['chatgpt_client_allowed_usage'] ) ? sanitize_text_field( $_POST['chatgpt_client_allowed_usage'] ) : '';
		$chatgpt_client_allowed_days = isset( $_POST['chatgpt_client_allowed_days'] ) ? sanitize_text_field( $_POST['chatgpt_client_allowed_days'] ) : '';
		$chatgpt_client_chatgpt_api_key = isset( $_POST['chatgpt_client_chatgpt_api_key'] ) ? sanitize_text_field( $_POST['chatgpt_client_chatgpt_api_key'] ) : '';
		
		$chatgpt_client_product_type = isset( $_POST['chatgpt_client_product_type'] ) ? sanitize_text_field( $_POST['chatgpt_client_product_type'] ) : '';
		
		update_post_meta( $post_id, 'chatgpt_client_allowed_installations', $allowed_installations );
		update_post_meta( $post_id, 'chatgpt_client_allowed_usage', $chatgpt_client_allowed_usage );
		update_post_meta( $post_id, 'chatgpt_client_allowed_days', $chatgpt_client_allowed_days );
		update_post_meta( $post_id, 'chatgpt_client_chatgpt_api_key', $chatgpt_client_chatgpt_api_key );
		update_post_meta( $post_id, 'chatgpt_client_product_type', $chatgpt_client_product_type );
	}

}

new CGPT_Server_Metabox();